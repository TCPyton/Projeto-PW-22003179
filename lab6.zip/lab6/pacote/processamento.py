def é_positivo(n):
    return n > 0


def é_par(n):
    return n % 2 == 0